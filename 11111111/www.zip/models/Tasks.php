<?php


class Tasks


{
    const SHOW_BY_DEFAULT = 3;

    public static function getTask($page = 1)
    {

        $db = Db::dbConnect();

        $page = intval($page);
        $offset = ($page - 1) * self::SHOW_BY_DEFAULT;

        $tasks = $db->get_results("SELECT*FROM user ORDER BY ID ASC LIMIT ". self::SHOW_BY_DEFAULT .
            " OFFSET " . $offset, ARRAY_A);

        if ($tasks) {
            foreach ($tasks as $row) {
                $rez[] = array('ID' => $row['ID'], 'user' => $row['user'], 'email' => $row['email']
                , 'task' => $row['task'], 'image' => $row['image'],'check'=>$row['check']);
            }

            return $rez;

        }

    }


    public static function getTaskID($ID)
    {

        $db = Db::dbConnect();

        $tasks = $db->get_results("SELECT*FROM user WHERE ID=".$db->escape($ID), ARRAY_A);

        if ($tasks) {
            foreach ($tasks as $row) {
                $rez[] = array('ID' => $row['ID'], 'user' => $row['user'],
                    'task' => $row['task'], 'image' => $row['image'],'check'=>$row['check']);
            }

            return $rez;

        }

    }



    public static function getListTasksCount()
    {
        $db = Db::dbConnect();
        $result = $db->get_var("SELECT count(ID) AS count FROM user ");

        return $result;

    }


    public static function addTask($user, $email, $task)
    {
        $db = Db::dbConnect();
        $add_user = $db->query("INSERT INTO `user` (`user`, `email`, `task`) 
              VALUES ('" . $db->escape($user) . "', '" . $db->escape($email) . "','" . $db->escape($task) . "')");

    }

    public static function addImage($user, $email, $task)
    {

        $path = 'i/';

 //       $types = array('image/gif', 'image/png', 'image/jpeg');

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (!@copy($_FILES['picture']['tmp_name'], $path . $_FILES['picture']['name']))
                echo 'Что-то пошло не так';
            else {
                echo 'Загрузка удачна';
                $image=$path . $_FILES['picture']['name'];
                $db = Db::dbConnect();
                $add_user = $db->query("INSERT INTO `user` (`user`, `email`, `task`,`image`) 
              VALUES ('" . $db->escape($user) . "', '" . $db->escape($email) . "','" . $db->escape($task) ."','" .
                    $db->escape($image). "')");


                $filename = $path . $_FILES['picture']['name'];
                echo $filename;

// получение нового размера
                list($width, $height) = getimagesize($filename);
                $newwidth = 240;
                $newheight = 320;
// загрузка
                $thumb = imagecreatetruecolor($newwidth, $newheight);

                if($_FILES['picture']['type']=='image/jpeg'){
                    $source = imagecreatefromjpeg($filename);

                }

                if($_FILES['picture']['type']=='image/png'){
                    $source = imagecreatefrompng($filename);

                }

                if($_FILES['picture']['type']=='image/gif'){
                    $source = imagecreatefromgif($filename);

                }

// изменение размера
                imagecopyresized($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);

                //if (!in_array($_FILES['picture']['type'], $types)) {

                    if($_FILES['picture']['type']=='image/jpeg'){
                    imagejpeg($thumb, $filename);
// вывод
                }

                if($_FILES['picture']['type']=='image/png'){
                    imagepng($thumb, $filename);
// вывод
                }

                if($_FILES['picture']['type']=='image/gif'){
                    imagegif($thumb, $filename);
// вывод
                }

            }


        }


    }


}