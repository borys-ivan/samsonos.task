<?php

include_once ROOT . '/models/Tasks.php';


include_once ROOT . '/components/Pagination.php';




//include_once ROOT . '/models/Product.php';

class SiteController
{

    public function actionIndex($page=1)
    {
        //$categories = array();
        $tasks = Tasks::getTask($page);

        if(isset($_POST['submit_image'])){

            $user = $_POST['user'];
            $email = $_POST['email'];
            $task = $_POST['task'];

           // $file_type=$_POST['file_type'];
           // $file_rotate=$_POST['file_rotate'];
            header("Location: /");


            Tasks::addImage($user,$email,$task);

            //Tasks::addTask($user,$email,$task);


        }



        $total = Tasks::getListTasksCount();

        $pagination_list_task = new Pagination($total, $page, Tasks::SHOW_BY_DEFAULT, 'page-');

        require_once(ROOT . '/view/site/index.php');

        return true;
    }


    public function actionLogin()
    {

        if (isset($_POST['user']) && isset($_POST['pass'])) {
            $user = $_POST['user'];
            $pass = $_POST['pass'];

            Cabinet::getUserID($user, $pass);
        }
        return true;
    }




}