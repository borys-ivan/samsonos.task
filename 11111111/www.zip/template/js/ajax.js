$(document).ready(function () {


        $('#user').one('focus', function () {

            $('#user').parent().after('<div id="preview-box"><div class="comment-by"><h3>Передпросмотр</h3></div>' +
                '<table class="table" ><tr><tr><th>Пользователь</th><th>email</th></tr><td id="user_td"></td><td id="email_td"></td><tr><th colspan="2">Задача</th></tr><tr><td colspan="3" id="task_td"</td></tr></table></div>');
        });

        var $user = ''; // that's two single quotation-marks at the end

        $('#user').keyup(function () {
            $user = $(this).val();

            $('#user_td').html($user);
        });

        var $email = '';

        $('#email').keyup(function () {
            $email = $(this).val();

            $('#email_td').html($email);
        });


        var $task = '';

        $('#task').keyup(function () {
            $task = $(this).val();

            $('#task_td').html($task);
        });


        return false;
    }
);

