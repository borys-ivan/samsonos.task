<?php

return array(
    
 //   'product/([0-9]+)' => 'product/view/$1', // actionView в ProductController

    
 //   'catalog' => 'catalog/index', // actionIndex в CatalogController
 //   'category/([0-9]+)' => 'catalog/category/$1',  // actionCategory в CatalogController



    'cabinet/update/([0-9]+)'=>'cabinet/update/$1',

    'cabinet/logout'=>'cabinet/logout',

    'cabinet/login'=>'cabinet/login',

    'cabinet'=>'cabinet/index',


    'page-([0-9]+)'=>'site/index/$1',

    '' => 'site/index', // actionIndex в SiteController

);
