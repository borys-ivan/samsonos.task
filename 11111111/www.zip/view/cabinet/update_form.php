<html>

<header>

    <!-- <script type="text/javascript" src="http://www.google.com/jsapi"></script>
     <script type="text/javascript">google.load("jquery", "1.2.6");</script>-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://code.jquery.com/jquery-latest.js"></script>


</header>


<body>




<div class="container">

<? foreach ($taskID as $row){?>

    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <h4>Стан</h4>
            <select name="check">
                <option value="<?echo $row['check']; ?>" selected="selected"><?if($row['check']==1){echo "Выполнен";}else{echo "Не исполнен";} ?></option>
                <option value="1">Выполнен</option>
                <option value="0">Не исполнен</option>
            </select>
            <h4>Задача</h4>
            <textarea class="form-control" id="task" name="task" rows="5" cols="40"><?echo $row['task']?></textarea> <br><br>
            <center><input class="btn btn-default" type="submit" value="Обновить" name="submit"></center>
        </div>
    </form>

    <?}?>

</div>


<!--<a href='#' id="delete_order"
    class="delete_order">Предпросмотер</a>-->




</body>


</html>