<html>

<header>

    <!-- <script type="text/javascript" src="http://www.google.com/jsapi"></script>
     <script type="text/javascript">google.load("jquery", "1.2.6");</script>-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://code.jquery.com/jquery-latest.js"></script>

    <style>

        .test1 {
            word-break: break-all;
            width: 50%;

        }

    </style>

</header>


<body>


<div class="jumbotron text-center">
    <h1>Admin</h1>


    <?php include ROOT . '/view/layouts/user_form.php'; ?>

</div>



<div class="container">

    <div class="table-striped">

        <br>
        <table class="table">

            <thead>
            <tr>
                <th colspan="2"><h3>Задачи</h3></th>

            </tr>
            </thead>
            <? foreach ($tasks as $row) { ?>
                <!--//пользователь-->

                <tr><center><td colspan="3"><h4><a href='/cabinet/update/<? echo $row['ID'] ?>'>Редактировать</a></h4></td></center></tr>

                <tr>

                    <td><h4><? echo $row['user'] ?></h4></td>
                    <td><h4><? echo $row['email'] ?></h4></td>
                    <td> Выполнение:
                        <center> <? if ($row['check'] == 1) { ?>
                                <p><input type="checkbox" name="a" value="true" checked></p>
                            <? } else { ?>
                                <p><input type="checkbox" name="a" value="true"></p>
                            <? } ?></center>
                    </td>
                </tr>
                <tr>
                    <td class="test1" colspan="2"><p><? echo $row['task'] ?></p></td>
                    <td colspan="3">
                        <center><img class="img-rounded" src="<? echo $row['image'] ?>"></center>
                    </td>
                </tr>


                <!--//image-->
                <img src="">

            <? } ?>

        </table>
    </div>
</div>

</body>



<script src="http://code.jquery.com/jquery-latest.js"></script>


</html>