<html>

<header>

    <link rel="stylesheet" type="text/css" href="/template/css/pagination.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="http://code.jquery.com/jquery-latest.js"></script>


    <style>

        .test1 {
            word-break: break-all;
            width: 50%;

        }

    </style>


</header>


<body>


<div class="jumbotron text-center">
    <h1>Task</h1>


    <?php include ROOT . '/view/layouts/user_form.php'; ?>

</div>


<div class="container">

    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <h4>Пользователь</h4>
            <input class="form-control" id="user" type="text" name="user"> <br>
            <h4>Email</h4>
            <input class="form-control" id="email" type="text" name="email"> <br>
            <h4>Задача</h4>
            <textarea class="form-control" id="task" name="task" rows="5" cols="40"></textarea> <br><br>

            <!-- <input id="task" type="text" name="task">-->

            <input type="file" name="picture"><br>
            <center><input class="btn btn-default" type="submit" value="Добавить задачу" name="submit_image"></center>
        </div>
    </form>

</div>


<div class="container">

    <div class="table-striped">

        <br>
        <table class="table">

            <thead>
            <tr>
                <th colspan="2"><h3>Задачи</h3></th>

            </tr>
            </thead>
            <? foreach ($tasks as $row) { ?>
                <!--//пользователь-->
                <tr>
                    <td><h4><? echo $row['user'] ?></h4></td>
                    <td><h4><? echo $row['email'] ?></h4></td>
                    <td> Выполнение:
                        <center> <? if ($row['check'] == 1) { ?>
                                <p><input type="checkbox" name="a" value="true" checked></p>
                            <? } else { ?>
                                <p><input type="checkbox" name="a" value="true"></p>
                            <? } ?></center>
                    </td>
                </tr>
                <tr>
                    <td class="test1" colspan="2"><p><? echo $row['task'] ?></p></td>
                    <td colspan="3">
                        <center><img class="img-rounded" src="<? echo $row['image'] ?>"></center>
                    </td>
                </tr>


            <? } ?>

        </table>
    </div>
</div>

<? echo $pagination_list_task->get(); ?>

</body>


<script>


</script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="/template/js/ajax.js"></script>

</html>